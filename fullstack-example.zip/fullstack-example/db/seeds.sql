USE pizza_db;

INSERT INTO pizza (name, price) VALUES ("New York", 12);
INSERT INTO pizza (name, price) VALUES ("Pepperonieee", 10);
INSERT INTO pizza (name, price) VALUES ("Veggie", 9);
INSERT INTO pizza (name, price) VALUES ("Supreme", 15);